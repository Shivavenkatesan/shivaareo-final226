<?php
// Aero Prime Med enquiry handler for Hostinger/PHP 8+.
$config = require __DIR__ . '/site-config.php';
$to = trim((string)($config['enquiry_email'] ?? ''));
$from = trim((string)($config['from_email'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: contact.html', true, 303);
    exit;
}
// Honeypot: silently accept bot submissions without sending mail.
if (!empty($_POST['website'])) {
    header('Location: contact.html?sent=1#enquiry', true, 303);
    exit;
}

function field(string $key, int $limit = 3000): string {
    $value = (string)($_POST[$key] ?? '');
    $value = str_replace(["\r", "\n", "\0"], ' ', $value);
    return trim(substr($value, 0, $limit));
}

$company = field('company', 120);
$name = field('name', 100);
$email = field('email', 254);
$phone = field('phone', 40);
$country = field('country', 80);
$products = field('products', 3000);
$message = field('message', 3000);

if (!$company || !$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$country || !$products) {
    header('Location: contact.html?error=1#enquiry', true, 303);
    exit;
}
// Do not pretend the form is operational until the owner configures a real mailbox.
if (!filter_var($to, FILTER_VALIDATE_EMAIL) || !filter_var($from, FILTER_VALIDATE_EMAIL)) {
    error_log('Aero Prime Med: configure enquiry_email and from_email in site-config.php.');
    header('Location: contact.html?config=1#enquiry', true, 303);
    exit;
}

$subject = 'New website enquiry from ' . $company;
$body = "Company: {$company}\nName: {$name}\nEmail: {$email}\nPhone: {$phone}\nCountry: {$country}\n\nProducts & quantities:\n{$products}\n\nDetails:\n{$message}\n";
$encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
$headers = [
    'From' => 'Aero Prime Med Website <' . $from . '>',
    'Reply-To' => $email,
    'MIME-Version' => '1.0',
    'Content-Type' => 'text/plain; charset=UTF-8',
];
$headerLines = [];
foreach ($headers as $key => $value) $headerLines[] = $key . ': ' . $value;
$sent = mail($to, $encodedSubject, $body, implode("\r\n", $headerLines));
header('Location: contact.html?' . ($sent ? 'sent=1' : 'error=1') . '#enquiry', true, 303);
exit;
