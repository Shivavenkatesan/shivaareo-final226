<?php
/**
 * Aero Prime Med site configuration.
 * Run: python3 set-domain.py yourdomain.com enquiries@yourdomain.com
 * This file is updated by that script. Do not expose secrets here.
 */
return [
    'site_url' => '',
    'enquiry_email' => '',
    'from_email' => '',
];
