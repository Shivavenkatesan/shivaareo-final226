#!/usr/bin/env python3
"""Optional: download remote catalogue/illustration images locally.
Run from the website root: python3 download-images.py
Failed downloads are left as remote URLs; empty files are never written.
"""
import re, glob, os, hashlib, urllib.request, urllib.error

os.makedirs('assets/images/catalogue', exist_ok=True)
pattern = re.compile(r'https://(?:www\.aeromedsintl\.com|images\.unsplash\.com)/[^"\')\s]+')
cache = {}

def local_copy(url):
    if url in cache:
        return cache[url]
    ext = '.jpg' if 'unsplash' in url else (os.path.splitext(url.split('?')[0])[1] or '.png')
    if 'aeromedsintl' in url:
        stem = url.split('?')[0].split('/imagess/')[-1].lower().rsplit('.', 1)[0]
        name = re.sub(r'[^a-z0-9]+', '-', stem).strip('-')
    else:
        name = 'photo-' + hashlib.md5(url.encode()).hexdigest()[:10]
    relative = 'assets/images/catalogue/' + name + ext
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=15) as response:
            data = response.read()
            content_type = response.headers.get('Content-Type', '')
        if len(data) < 1024 or not content_type.startswith('image/'):
            raise ValueError('response was not a valid image')
        with open(relative, 'wb') as output:
            output.write(data)
        cache[url] = relative
        print('Downloaded', relative)
    except Exception as error:
        print('FAILED (kept remote URL)', url, '-', error)
        cache[url] = url
    return cache[url]

for filename in glob.glob('*.html'):
    with open(filename, encoding='utf-8') as source:
        original = source.read()
    updated = pattern.sub(lambda match: local_copy(match.group(0)), original)
    if updated != original:
        with open(filename, 'w', encoding='utf-8') as target:
            target.write(updated)
print('Downloaded', sum(value.startswith('assets/') for value in cache.values()), 'of', len(cache), 'images')
