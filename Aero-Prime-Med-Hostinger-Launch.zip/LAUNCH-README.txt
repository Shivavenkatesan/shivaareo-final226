AERO PRIME MED - HOSTINGER LAUNCH PACKAGE

IMPORTANT: The website files are prepared, but the domain and email account are not known yet.
Do not consider the enquiry form live until you complete the configuration below and test it.

1) On your computer, extract this ZIP.
2) Open a terminal/command prompt inside the extracted lab-agile-planning-main folder.
3) Run (replace with your real details):
     python3 set-domain.py yourdomain.com enquiries@yourdomain.com noreply@yourdomain.com
   This writes the canonical URLs, Open Graph URLs, sitemap.xml, robots.txt and site-config.php.
   The sender address must be a mailbox or alias created on your Hostinger domain.
4) In Hostinger hPanel > Emails, create the enquiry mailbox and sender mailbox/alias.
5) In Hostinger hPanel > Security > SSL, activate SSL for your domain.
6) Upload the CONTENTS of lab-agile-planning-main (including hidden .htaccess and site-config.php)
   into public_html. Do not upload the parent folder itself.
7) Visit https://yourdomain.com/contact.html and send a real test enquiry.
   Confirm delivery to the enquiry mailbox and check spam. Hostinger/PHP mail delivery depends
   on the mailbox/domain configuration; this cannot be verified before deployment.
8) Submit https://www.yourdomain.com/sitemap.xml in Google Search Console.
   This package standardises the canonical host to www.yourdomain.com.

FILES / NOTES
- index.html is the homepage; contact.php handles the enquiry form.
- site-config.php is required by contact.php and must be uploaded.
- set-domain.py configures your real domain and email addresses.
- download-images.py is optional. It downloads third-party catalogue imagery; remote image hosts
  may block requests. Check the catalogue after launch and replace any unavailable images with
  images you have permission to use.
- Product descriptions/specifications, regulatory claims, business contact details and legal text
  must be reviewed and approved by the business before publication.
- This package has not been tested on your live Hostinger account/domain.
