#!/usr/bin/env python3
"""Configure Aero Prime Med for Hostinger.
Usage: python3 set-domain.py example.com enquiries@example.com [noreply@example.com]
Run from the website root folder before uploading to public_html.
"""
import sys, re, pathlib

if len(sys.argv) < 3:
    print(__doc__)
    raise SystemExit(2)

domain = sys.argv[1].strip().lower()
domain = re.sub(r'^https?://', '', domain).strip('/').removeprefix('www.')
email = sys.argv[2].strip()
from_email = sys.argv[3].strip() if len(sys.argv) > 3 else f'noreply@{domain}'
if not re.fullmatch(r'(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}', domain):
    raise SystemExit('Invalid domain. Enter a domain such as aeroprimemed.com')
for value, label in ((email, 'enquiry email'), (from_email, 'sender email')):
    if not re.fullmatch(r"[^\s@'\\]+@[^\s@'\\]+\.[^\s@'\\]+", value):
        raise SystemExit(f'Invalid {label}: {value}')

base = pathlib.Path(__file__).resolve().parent
site_url = f'https://www.{domain}'
# Canonical + Open Graph URLs on indexable HTML pages.
for page in base.glob('*.html'):
    text = page.read_text(encoding='utf-8')
    text = text.replace('href="contact.html#enquiry">the enquiry form</a>', f'href="mailto:{email}">{email}</a>')
    text = text.replace('href="contact.html#enquiry">use the enquiry form</a>', f'href="mailto:{email}">{email}</a>')
    if page.name != '404.html':
        page_path = '/' if page.name == 'index.html' else '/' + page.name
        canonical = f'<link href="{site_url}{page_path}" rel="canonical"/>\n'
        og_url = f'<meta content="{site_url}{page_path}" property="og:url"/>\n'
        text = re.sub(r'</head>', canonical + og_url + '</head>', text, count=1, flags=re.I)
    page.write_text(text, encoding='utf-8')

# Build a valid sitemap for the configured canonical host.
pages = ['', 'about.html', 'products.html', 'wholesale.html', 'international.html',
         'quality.html', 'resources.html', 'contact.html', 'privacy.html', 'terms.html']
items = '\n'.join(f'  <url><loc>{site_url}/{p}</loc></url>' for p in pages)
(base / 'sitemap.xml').write_text(
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    + items + '\n</urlset>\n', encoding='utf-8')
(base / 'robots.txt').write_text(f'User-agent: *\nAllow: /\n\nSitemap: {site_url}/sitemap.xml\n', encoding='utf-8')
(base / 'site-config.php').write_text(
    "<?php\nreturn [\n"
    f"    'site_url' => '{site_url}',\n"
    f"    'enquiry_email' => '{email}',\n"
    f"    'from_email' => '{from_email}',\n"
    "];\n", encoding='utf-8')
print(f'Configured domain: {site_url}')
print(f'Enquiries: {email}')
print(f'Sender: {from_email}')
